package com.codingshuttle.homework.week1.week.one.Home.work;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "have.flavour",havingValue="strawberry")
public class StrawberryFrosting implements Frosting{
    @Override
    public String getFrosting() {
        return "Strawberry Frosting";
    }

}
