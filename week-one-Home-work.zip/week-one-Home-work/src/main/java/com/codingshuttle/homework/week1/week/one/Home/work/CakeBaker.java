package com.codingshuttle.homework.week1.week.one.Home.work;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.sound.midi.Soundbank;

@Component
public class CakeBaker {

    @Autowired
    Frosting frosting;

    public Syrup syrup;
    CakeBaker(Syrup syrup){
        this.syrup=syrup;
    }


    public void bakeCake(){
        System.out.print("Baking Cake with " );
        System.out.print(syrup.getSyrup()+" "+"and"+" " );
        System.out.print(frosting.getFrosting());
    }

}
