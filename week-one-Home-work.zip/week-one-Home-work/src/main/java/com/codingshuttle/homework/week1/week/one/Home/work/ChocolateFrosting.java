package com.codingshuttle.homework.week1.week.one.Home.work;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "have.flavour",havingValue="chocolate")
public class ChocolateFrosting implements Frosting{
    @Override
    public String getFrosting() {
        return "Chocolate Frosting";
    }
}
