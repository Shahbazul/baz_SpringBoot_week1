package com.codingshuttle.homework.week1.week.one.Home.work;

public interface Frosting {

    String getFrosting();

}
