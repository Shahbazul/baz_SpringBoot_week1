package com.codingshuttle.homework.week1.week.one.Home.work;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeekOneHomeWorkApplicationTests {

	@Test
	void contextLoads() {
	}

}
